# LoominLink installer. ASCII only.
param([switch]$HeadsetOnly)
. (Join-Path $PSScriptRoot 'Common.ps1')
$Src = Split-Path $PSScriptRoot -Parent
$Host.UI.RawUI.WindowTitle = "$AppName $AppVersion installer"

function Install-HeadsetApp {
  Step 'Headset app'
  $apk = Join-Path $Src 'headset\LoominLink.apk'
  $adb = Get-Adb
  if (-not $adb) { Say 'Skipped: no ADB. Run "tools\Install headset app.bat" later.' DarkYellow; return }
  Say 'Turn the headset on and connect it to this PC with a USB cable (USB debugging must be enabled - see README).' White
  Pause-Key
  & $adb disconnect 2>$null | Out-Null
  if (-not (Wait-Headset $adb)) { Say 'No headset found over USB. Check the cable / USB debugging and run "tools\Install headset app.bat".' Red; return }
  & $adb shell am force-stop $Package 2>$null | Out-Null
  $out = & $adb install -r -d $apk 2>&1 | Out-String
  if ($out -notmatch 'Success') {
    Say "Install said: $($out.Trim())" DarkYellow
    if (Ask 'Remove the old LoominLink app from the headset and install fresh?') {
      & $adb uninstall $Package 2>&1 | Out-Null; $out = & $adb install $apk 2>&1 | Out-String } }
  if ($out -match 'Success') {
    & $adb shell pm grant $Package android.permission.RECORD_AUDIO 2>$null | Out-Null
    Say 'Headset app installed.' Green
  } else { Say "Headset app NOT installed: $($out.Trim())" Red; return }
  Say 'Rebooting the headset (streaming right after a USB/ADB session can crash it - a reboot avoids that).' White
  & $adb shell sync 2>$null | Out-Null; & $adb reboot 2>$null | Out-Null
  Say 'Unplug the USB cable.' White
}

if ($HeadsetOnly) { Install-HeadsetApp; Pause-Key; exit }

Clear-Host
Say "  $AppName $AppVersion - wireless, eye-tracked foveated SteamVR streaming for the Pimax Crystal (standalone mode)" Cyan
Say '  EXPERIMENTAL test build. Not affiliated with Pimax or Valve. Use at your own risk - see README.' DarkYellow
Say ''
Say 'This installer will:'
Say "  1. copy LoominLink to $InstallDir"
Say '  2. register the LoominLink SteamVR driver and make SteamVR use it (your steamvr.vrsettings is backed up first)'
Say '  3. allow LoominLink through Windows Firewall (asks for administrator permission)'
Say '  4. add a "LoominLink Control" shortcut to the Desktop and Start menu'
Say '  5. optionally install the headset app over USB'
if (-not (Ask 'Continue?')) { exit }

Step 'Checking the download'
$manifest = Join-Path $PSScriptRoot 'files.sha256'; $bad = @()
if (-not (Test-Path $manifest)) { $bad += 'files.sha256 (missing)' }
else { foreach ($line in Get-Content $manifest) {
  if ($line -notmatch '^([0-9a-f]{64})\s+(.+)$') { continue }
  $f = Join-Path $Src $Matches[2]
  if (-not (Test-Path $f) -or (Get-FileHash $f -Algorithm SHA256).Hash.ToLower() -ne $Matches[1]) { $bad += $Matches[2] } } }
if ($bad.Count) { Say 'This copy of LoominLink has been modified or is incomplete:' Red; $bad | ForEach-Object { Say "  $_" Red }
  Say 'Please download the official release again.' Red; Pause-Key; exit 1 }
Say 'Files verified (official release).' Green

Step 'Checking this PC'
$vrbin = Get-SteamVRBin
if (-not $vrbin) { Say 'SteamVR was not found. Install Steam + SteamVR first, run SteamVR once, then run this installer again.' Red; Pause-Key; exit 1 }
Say "SteamVR: $vrbin" Green
$gpu = (Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object Name) -join ', '
if ($gpu -match 'NVIDIA') { Say "GPU: $gpu" Green } else { Say "GPU: $gpu - LoominLink needs an NVIDIA GPU (NVENC HEVC encoder). It will not stream on this PC." Red; if (-not (Ask 'Install anyway?')) { exit 1 } }
$snd = (Get-CimInstance Win32_SoundDevice -ErrorAction SilentlyContinue | ForEach-Object Name) -join ', '
if ($snd -match 'VB-Audio') { Say 'VB-Audio Virtual Cable: found (headset microphone will work)' Green }
else { Say 'VB-Audio Virtual Cable: not found. Optional - install it (vb-audio.com/Cable) if you want to use the headset microphone on the PC.' DarkYellow }

if (Get-Process vrserver, vrmonitor, vrcompositor -ErrorAction SilentlyContinue) {
  Say 'SteamVR is running and has to be closed.' White
  if (Ask 'Close SteamVR now?') { Get-Process vrmonitor, vrserver, vrcompositor, vrdashboard, vrwebhelper -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2 }
  else { Say 'Close SteamVR and run the installer again.' Red; Pause-Key; exit 1 } }

Step 'Copying files'
New-Item -ItemType Directory -Force $InstallDir | Out-Null
$vrsDst = Join-Path $DriverDir 'resources\settings\default.vrsettings'
$keep = $null; if (Test-Path $vrsDst) { $keep = Get-Content $vrsDst -Raw }
$pcDir = Join-Path $Src 'pc'
foreach ($f in (Get-ChildItem $pcDir -Recurse -File)) {   # file by file, so updates never nest folders
  $dst = Join-Path $InstallDir $f.FullName.Substring($pcDir.Length + 1)
  New-Item -ItemType Directory -Force (Split-Path $dst -Parent) | Out-Null
  Copy-Item $f.FullName $dst -Force }
if ($keep) { Set-Content $vrsDst $keep -NoNewline; Say 'Kept your existing LoominLink settings (update install).' Green }
Get-ChildItem $InstallDir -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
Say "Installed to $InstallDir" Green

Step 'Registering the SteamVR driver'
$vrpathreg = Join-Path $vrbin 'vrpathreg.exe'
foreach ($line in (& $vrpathreg show 2>$null)) {   # remove other copies of this driver (old test folders)
  if ($line -match '^\s*gazedot\s*:\s*(.+?)\s*$' -and ($Matches[1].TrimEnd('\') -ne $DriverDir)) { & $vrpathreg removedriver $Matches[1] | Out-Null; Say "Removed an older registration: $($Matches[1])" } }
& $vrpathreg adddriver $DriverDir | Out-Null
Say 'Driver registered.' Green
$cfg = Get-SteamVRSettingsPath
try {
  if ($cfg -and (Test-Path $cfg)) {
    $bak = "$cfg.loominlink-backup"; if (-not (Test-Path $bak)) { Copy-Item $cfg $bak; Say "Backed up steamvr.vrsettings to $bak" }
    $j = Get-Content $cfg -Raw | ConvertFrom-Json } else { $j = [pscustomobject]@{} }
  if (-not $j.steamvr) { $j | Add-Member steamvr ([pscustomobject]@{}) }
  $j.steamvr | Add-Member -Force forcedDriver 'gazedot'
  $j.steamvr | Add-Member -Force activateMultipleDrivers $true
  if ($cfg) { $j | ConvertTo-Json -Depth 30 | Set-Content $cfg -Encoding UTF8; Say 'SteamVR set to use LoominLink (base-station controllers and trackers can still connect).' Green }
} catch { Say "Could not edit steamvr.vrsettings automatically: $($_.Exception.Message)" Red
          Say 'In SteamVR settings set "forcedDriver" to "gazedot" and "activateMultipleDrivers" to true (see README).' DarkYellow }

Step 'Windows Firewall'
$vrserver = Join-Path $vrbin 'vrserver.exe'
$fw = "netsh advfirewall firewall delete rule name=`"$($FwRules[0])`" | Out-Null; netsh advfirewall firewall add rule name=`"$($FwRules[0])`" dir=in action=allow protocol=UDP localport=9943 profile=any | Out-Null; " +
      "netsh advfirewall firewall delete rule name=`"$($FwRules[1])`" | Out-Null; netsh advfirewall firewall add rule name=`"$($FwRules[1])`" dir=in action=allow program=`"$vrserver`" profile=any | Out-Null"
try { Invoke-Elevated $fw; Say 'Firewall rules added (headset discovery + SteamVR).' Green }
catch { Say 'Firewall step skipped (permission refused). If the headset cannot find the PC, run the installer again and allow it.' DarkYellow }

Step 'Shortcuts'
$ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$sh = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $l = $sh.CreateShortcut((Join-Path $dir 'LoominLink Control.lnk'))
  $l.TargetPath = $ps; $l.WorkingDirectory = $InstallDir; $l.WindowStyle = 7
  $l.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $InstallDir 'LoominLink_Control.ps1')`""
  $l.IconLocation = (Join-Path $InstallDir 'LoominLink.ico') + ',0'; $l.Description = 'LoominLink Control'; $l.Save() }
Say '"LoominLink Control" added to the Desktop and Start menu.' Green

if (Ask 'Install or update the headset app now (needs a USB cable)?') { Install-HeadsetApp }

Step 'Done'
Say 'To play:' White
Say '  1. Put on the headset and open LoominLink from the Pimax home (Library).'
Say '  2. Start SteamVR on the PC. The headset finds the PC by itself (same network, PC wired to the router is best).'
Say '  3. Use "LoominLink Control" on the desktop to tune settings. Keep Bitrate at 120 Mbps or lower.'
Pause-Key
