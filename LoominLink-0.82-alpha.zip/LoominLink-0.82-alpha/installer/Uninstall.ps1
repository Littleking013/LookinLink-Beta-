# LoominLink uninstaller. ASCII only.
. (Join-Path $PSScriptRoot 'Common.ps1')
$Host.UI.RawUI.WindowTitle = "$AppName uninstaller"
Say "Uninstall $AppName from this PC." Cyan
if (-not (Ask 'Continue?')) { exit }

if (Get-Process vrserver, vrmonitor -ErrorAction SilentlyContinue) {
  if (Ask 'SteamVR is running. Close it now?') { Get-Process vrmonitor, vrserver, vrcompositor, vrdashboard, vrwebhelper -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 2 } }

Step 'SteamVR'
$vrbin = Get-SteamVRBin
if ($vrbin) { & (Join-Path $vrbin 'vrpathreg.exe') removedriver $DriverDir | Out-Null; Say 'Driver unregistered.' Green }
$cfg = Get-SteamVRSettingsPath
try {
  if ($cfg -and (Test-Path $cfg)) {
    $j = Get-Content $cfg -Raw | ConvertFrom-Json
    if ($j.steamvr -and $j.steamvr.forcedDriver -eq 'gazedot') { $j.steamvr.PSObject.Properties.Remove('forcedDriver') }
    if ($j.driver_gazedot -and (Ask 'Also delete LoominLink settings and controller calibration stored in SteamVR?')) { $j.PSObject.Properties.Remove('driver_gazedot') }
    $j | ConvertTo-Json -Depth 30 | Set-Content $cfg -Encoding UTF8; Say 'SteamVR settings restored to normal headset selection.' Green }
} catch { Say "Could not edit steamvr.vrsettings: $($_.Exception.Message). Remove forcedDriver=gazedot by hand, or restore $cfg.loominlink-backup" Red }

Step 'Firewall'
$fw = ($FwRules | ForEach-Object { "netsh advfirewall firewall delete rule name=`"$_`" | Out-Null" }) -join '; '
try { Invoke-Elevated $fw; Say 'Firewall rules removed.' Green } catch { Say 'Skipped (permission refused).' DarkYellow }

Step 'Shortcuts and files'
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) { Remove-Item (Join-Path $dir 'LoominLink Control.lnk') -ErrorAction SilentlyContinue }
if (Ask 'Also remove the LoominLink app from the headset (needs USB)?') {
  $adb = Find-Adb
  if ($adb) { Say 'Connect the headset by USB.' White; Pause-Key
    if (Wait-Headset $adb) { & $adb uninstall $Package | Out-Null; & $adb reboot | Out-Null; Say 'Headset app removed; headset rebooting.' Green } else { Say 'Headset not found - skipped.' DarkYellow } }
  else { Say 'ADB not found - skipped.' DarkYellow } }
Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
Say "Removed $InstallDir" Green
Step 'Done'
Pause-Key
