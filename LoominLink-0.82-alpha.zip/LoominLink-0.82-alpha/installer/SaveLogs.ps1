# Collects LoominLink logs into a zip on the Desktop, with headset serial numbers, MAC and IP addresses removed. ASCII only.
. (Join-Path $PSScriptRoot 'Common.ps1')
$Host.UI.RawUI.WindowTitle = 'LoominLink - save logs'
$stamp = Get-Date -Format 'yyyy-MM-dd_HHmm'
$tmp = Join-Path $env:TEMP "LoominLink-logs-$stamp"; New-Item -ItemType Directory -Force $tmp | Out-Null
Say 'Collecting LoominLink logs. If the headset just crashed, do NOT restart it first - its log is still in memory.' White

$s = Get-SteamPath
if ($s) { foreach ($n in 'vrserver.txt', 'vrserver.previous.txt', 'vrcompositor.txt') { $p = Join-Path $s "logs\$n"; if (Test-Path $p) { Copy-Item $p $tmp } } }
foreach ($n in 'status.txt', 'live.txt', 'resources\settings\default.vrsettings') { $p = Join-Path $DriverDir $n; if (Test-Path $p) { Copy-Item $p $tmp } }

if (Ask 'Also collect the headset logs (needs the USB cable; the headset reboots afterwards)?') {
  $adb = Find-Adb
  if (-not $adb) { Say 'ADB not found - run the installer first (it can download it).' DarkYellow }
  else { Say 'Connect the headset by USB.' White; Pause-Key
    if (Wait-Headset $adb) {
      & $adb logcat -d -v time 2>&1 | Out-File (Join-Path $tmp 'headset_log.txt') -Encoding ascii
      & $adb pull "/sdcard/Android/data/$Package/files/blackbox.txt" (Join-Path $tmp 'blackbox.txt') 2>&1 | Out-Null
      & $adb shell "dumpsys package $Package | grep -i versionName; getprop sys.boot.reason; getprop ro.build.fingerprint" 2>&1 | Out-File (Join-Path $tmp 'headset_info.txt') -Encoding ascii
      & $adb reboot | Out-Null; Say 'Headset logs saved; headset rebooting (unplug it).' Green }
    else { Say 'Headset not found - skipped.' DarkYellow } } }

Say 'Removing serial numbers, MAC and IP addresses...' White
foreach ($f in Get-ChildItem $tmp -File) {
  $t = Get-Content $f.FullName -Raw -ErrorAction SilentlyContinue; if (-not $t) { continue }
  $t = $t -replace 'VRD\d\d-[A-Za-z0-9-]+', 'VRDxx-REDACTED' -replace '(?i)\b([0-9a-f]{2}:){5}[0-9a-f]{2}\b', 'xx:xx:xx:xx:xx:xx' -replace '\b(\d{1,3}\.){3}\d{1,3}\b', 'x.x.x.x'
  $t = $t -replace [regex]::Escape($env:USERNAME), 'USER'
  Set-Content $f.FullName $t -NoNewline }
$zip = Join-Path ([Environment]::GetFolderPath('Desktop')) "LoominLink-logs-$stamp.zip"
Compress-Archive (Join-Path $tmp '*') $zip -Force; Remove-Item $tmp -Recurse -Force
Say "Saved: $zip" Green
Say 'Please look through it before sharing publicly.' DarkYellow
Pause-Key
