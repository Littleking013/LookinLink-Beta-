# LoominLink (alpha)

Wireless, eye-tracked **foveated** SteamVR streaming for the **Pimax Crystal (original)** in standalone (all-in-one) mode.

The PC renders the game, LoominLink sends a compressed video over Wi-Fi with full detail where your eyes are looking (using the Crystal's eye tracking) and less towards the edges, and the headset shows it with its own head tracking and lens correction.

> **Experimental test build.** Expect bugs and crashes. Not affiliated with, endorsed by, or supported by Pimax or Valve. Use at your own risk.

## What you need

| | |
|---|---|
| Headset | Pimax Crystal (original / "OG") in standalone mode, with **USB debugging (ADB)** enabled |
| PC | Windows 10/11, **NVIDIA GPU** (uses NVENC HEVC), SteamVR installed |
| Network | A good 5 GHz / 6 GHz router; the PC **wired** to the router; headset on the same network |
| Optional | [VB-Audio Virtual Cable](https://vb-audio.com/Cable/) to use the headset microphone on the PC |
| Optional | SteamVR base stations + Index controllers / Vive trackers (one USB dongle per device on the PC) |

### Enabling USB debugging on the headset

> **TODO (maintainer):** add the steps for your Crystal firmware here.

## Install

1. Unzip anywhere.
2. Double-click **`Install LoominLink.bat`** and follow the prompts. It:
   - copies LoominLink to `%LOCALAPPDATA%\LoominLink`
   - registers the SteamVR driver and sets SteamVR to use it (your `steamvr.vrsettings` is backed up as `steamvr.vrsettings.loominlink-backup`)
   - adds Windows Firewall rules so the headset can find the PC (asks for admin)
   - adds a **LoominLink Control** shortcut to the Desktop and Start menu
   - optionally installs the headset app over USB (downloads Google's ADB tools if you don't have them)
3. After installing the headset app, the headset reboots. This is intentional: streaming right after a USB/ADB session can crash the headset.

Updating: run the new version's installer. Your LoominLink settings are kept.

## Play

1. In the headset, open **LoominLink** from the Pimax library. A waiting screen explains what to do (and how to get back to Pimax home).
2. Start **SteamVR** on the PC. The headset connects automatically.
3. Open **LoominLink Control** on the PC to tune settings while you play.

## LoominLink Control

- **Settings:** bitrate, frames in flight, prediction, heat guard, decoder guard, mic delay; plus stream/render size (needs a SteamVR restart).
- **Foveation:** shape (width/height) and soft edge of the full-detail area, with a preview, presets and a "show zones" overlay.
- **Tracking:** Pimax controllers or Index controllers, inside-out or base-station (lighthouse) tracking, Pimax controller smoothing.
- **Calibration:** aligns the headset's tracking with base-station space (for trackers / Index controllers). Hold the right Pimax controller firmly together with a lighthouse device (right Index controller, or a Vive tracker with the others switched off), start calibration, then turn them to ~8 different angles, pausing ~1 s at each.

## Known issues (please read)

- **Keep Bitrate at 120 Mbps or lower.** Higher bitrates can overwhelm the headset's video decoder and crash the headset.
- **Heat:** after 10-20 minutes the headset's processor gets hot and slows down, which shows up as stutter and lag. The heat guard lowers the bitrate when it's hot. A fan blowing on the headset helps.
- **Crashes:** the headset sometimes crashes (and may need a full power-off afterwards). If it crashes repeatedly within seconds, power it fully off for 30 s.
- **Lighthouse faceplate:** in standalone mode the headset cannot use the faceplate, so base-station tracking of the headset itself is not available; controllers/trackers need their own USB dongles on the PC.
- "Encoder bit-focus mode" (Foveation tab) is off by default; it may cause crashes on this headset.

## Reporting a problem

Run **`tools\Save logs for a bug report.bat`** right after the problem (don't restart the headset first). It saves a zip on your Desktop with serial numbers, MAC and IP addresses removed. Please still look through it before posting it publicly.

## Uninstall

Double-click **`Uninstall LoominLink.bat`**. It removes the driver, restores SteamVR's normal headset selection, removes the firewall rules and shortcuts, and can remove the headset app.

## License

LoominLink is free to use during the open beta, but it is **not open source**: modifying, redistributing or reverse engineering it is not allowed. See [LICENSE.txt](LICENSE.txt).

Only download LoominLink from the official release page. The installer checks its files and refuses to install a modified copy. To check a download yourself, compare its SHA-256 (`Get-FileHash LoominLink-0.82-alpha.zip` in PowerShell) with the one on the release page.

## Version

0.82-alpha: headset app 0.82, SteamVR driver v43, LoominLink Control v14.
