@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\installer\Install.ps1" -HeadsetOnly
if errorlevel 1 pause
