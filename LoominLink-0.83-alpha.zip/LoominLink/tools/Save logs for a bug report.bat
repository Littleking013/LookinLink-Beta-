@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\installer\SaveLogs.ps1" 
if errorlevel 1 pause
