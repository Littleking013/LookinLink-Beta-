@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\installer\Install.ps1" -FanOnly
if errorlevel 1 pause
