# LoominLink installer - shared helpers. ASCII only (Windows PowerShell 5.1 reads scripts as ANSI).
$ErrorActionPreference = 'Stop'
$AppName    = 'LoominLink'
$AppVersion = '0.83-alpha'
$Package    = 'com.crystaltools.gazedot'          # headset app id
$InstallDir = Join-Path $env:LOCALAPPDATA 'LoominLink'
$DriverDir  = Join-Path $InstallDir 'gazedot'
$FwRules    = @('LoominLink headset discovery', 'LoominLink SteamVR')

function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Step($t) { Write-Host ''; Write-Host "== $t" -ForegroundColor Yellow }
function Ask($q) { $a = Read-Host "$q [Y/n]"; return ($a -eq '' -or $a -match '^[yY]') }
function AskNo($q) { $a = Read-Host "$q [y/N]"; return ($a -match '^[yY]') }
function Pause-Key { Write-Host ''; Read-Host 'Press Enter to continue' | Out-Null }

function Get-SteamPath {
  try { $p = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath } catch { return $null }
  if ($p) { return ($p -replace '/', '\') } else { return $null }
}
function Get-SteamVRBin {
  $s = Get-SteamPath; if (-not $s) { return $null }
  $cands = @(Join-Path $s 'steamapps\common\SteamVR\bin\win64')
  $lib = Join-Path $s 'steamapps\libraryfolders.vdf'
  if (Test-Path $lib) {
    foreach ($m in [regex]::Matches((Get-Content $lib -Raw), '"path"\s+"([^"]+)"')) {
      $cands += (Join-Path ($m.Groups[1].Value -replace '\\\\', '\') 'steamapps\common\SteamVR\bin\win64') }
  }
  foreach ($c in $cands) { if (Test-Path (Join-Path $c 'vrpathreg.exe')) { return $c } }
  return $null
}
function Get-SteamVRSettingsPath { $s = Get-SteamPath; if ($s) { return (Join-Path $s 'config\steamvr.vrsettings') } else { return $null } }

function Find-Adb {
  $c = @()
  $w = Get-Command adb.exe -ErrorAction SilentlyContinue; if ($w) { $c += $w.Source }
  $c += (Join-Path $InstallDir 'platform-tools\adb.exe'), 'C:\platform-tools\adb.exe', (Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe')
  foreach ($p in $c) { if ($p -and (Test-Path $p)) { return $p } }
  return $null
}
function Get-Adb {
  $a = Find-Adb; if ($a) { return $a }
  Say 'ADB (Android Debug Bridge, from Google) is needed to install the headset app.' White
  if (-not (Ask 'Download Google platform-tools now (about 7 MB) into the LoominLink folder?')) { return $null }
  $zip = Join-Path $env:TEMP 'platform-tools-latest-windows.zip'
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile $zip -UseBasicParsing
  New-Item -ItemType Directory -Force $InstallDir | Out-Null
  Expand-Archive $zip -DestinationPath $InstallDir -Force; Remove-Item $zip -Force
  return (Find-Adb)
}
function Wait-Headset($adb) {
  for ($i = 0; $i -lt 60; $i++) {
    $d = & $adb devices 2>$null | Select-String "`tdevice$"
    if ($d) { return $true }
    if ($i -eq 0) { Say 'Waiting for the headset over USB... (accept the "Allow USB debugging" prompt inside the headset if it appears)' White }
    Start-Sleep 2 }
  return $false
}
function Invoke-Elevated([string]$cmd) {   # run a command as administrator; -EncodedCommand keeps quotes intact
  $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cmd))
  Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile', '-EncodedCommand', $enc
}
