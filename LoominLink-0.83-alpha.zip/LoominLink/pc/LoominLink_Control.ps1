# LoominLink Control - settings + calibration (Windows PowerShell + WinForms, nothing to install)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'Stop'
try {
$root   = Join-Path $PSScriptRoot 'gazedot'
$live   = Join-Path $root 'live.txt'
$status = Join-Path $root 'status.txt'
$calTrigger = Join-Path $root 'calibrate_now'
$vrs    = Join-Path $root 'resources\settings\default.vrsettings'
function Read-KV($path) { $h = @{}; if (Test-Path $path) { Get-Content $path | ForEach-Object { if ($_ -match '^\s*(\w+)\s*=\s*(.+?)\s*$') { $h[$matches[1]] = $matches[2] } } }; return $h }
function Get-Vr { Get-Content $vrs -Raw | ConvertFrom-Json }

# key, label, unit, min, max, step, scale (slider int = value*scale), kind: live | restart | calib, default, hint
$defs = @(
  @{k='bitrateMbps';       n='Bitrate';              u='Mbps'; min=40;   max=250;  step=5;    sc=1;   kind='live';    def=120;  hint='100-150 is the sweet spot; higher mostly adds heat'},
  @{k='maxFramesInFlight'; n='Frames in flight';     u='';     min=1;    max=6;    step=1;    sc=1;   kind='live';    def=3;    hint='Higher = fewer skipped frames on slow Wi-Fi, a little more delay'},
  @{k='displayPredictMs';  n='Display prediction';   u='ms';   min=0;    max=60;   step=1;    sc=1;   kind='live';    def=20;   hint='Final head-correction look-ahead'},
  @{k='photonSeconds';     n='Controller prediction';u='ms';   min=0;    max=120;  step=5;    sc=1;   kind='live';    def=50;   hint='How far ahead SteamVR predicts controllers'; ms=$true},
  @{k='heatGuardC';        n='Heat guard';           u='C';    min=0;    max=60;   step=1;    sc=1;   kind='live';    def=47;   hint='Ease bitrate off above this headset temperature (0 = off)'},
  @{k='decoderGuardMs';    n='Decoder guard';        u='ms';   min=0;    max=25;   step=0.5;  sc=10;  kind='live';    def=13;   hint='Lower the bitrate when the headset takes longer than this to decode a frame. 0 = off'},
  @{k='micDelayMs';        n='Mic delay';            u='ms';   min=10;   max=80;   step=5;    sc=1;   kind='live';    def=25;   hint='Audio kept in reserve for the headset mic. Lower = less delay; raise it if your voice crackles'},
  @{k='tanHalfFov';        n='Margin (view width)';  u='';     min=1.10; max=1.50; step=0.01; sc=100; kind='restart'; def=1.15; hint='Wider = fewer black edges when turning, slightly softer'},
  @{k='eyeRenderTarget';   n='Render size per eye';  u='px';   min=2000; max=3200; step=40;   sc=1;   kind='restart'; def=2640; hint='Game resolution - higher = sharper, more GPU time'},
  @{k='eyeStream';         n='Stream size per eye';  u='px';   min=1024; max=1536; step=64;   sc=1;   kind='restart'; def=1280; hint='Pixels sent to the headset - higher = more decoder load'},
  @{k='pimaxCtrlPrediction'; n='Prediction';        u='%';    min=0;    max=150;  step=5;    sc=1;   kind='ctrl';    def=100;  hint='0 = old behaviour. Lower if hands overshoot/wobble, raise if they trail behind'; pct=$true},
  @{k='pimaxCtrlLeadMs';   n='Extra look-ahead';     u='ms';   min=-30;  max=60;   step=2;    sc=1;   kind='ctrl';    def=0;    hint='+ if fast swings still lag, - if they overshoot when you stop'},
  @{k='pimaxCtrlStillCmS'; n='Still-hand steadiness';u='cm/s'; min=0;    max=20;   step=0.5;  sc=10;  kind='ctrl';    def=4;    hint='Higher = calmer when holding still, slightly slower to start moving'},
  @{k='fovWidth';          n='Sharp width';          u='';     min=0.10; max=0.60; step=0.01; sc=100; kind='fov';     def=0.30; hint='Width of the full-detail area around your gaze (fraction of the view)'},
  @{k='fovHeight';         n='Sharp height';         u='';     min=0.10; max=0.60; step=0.01; sc=100; kind='fov';     def=0.30; hint='Height of it - lower than width = a wide oval, higher = a tall one'},
  @{k='fovGradient';       n='Soft edge';            u='';     min=0.00; max=0.30; step=0.01; sc=100; kind='fov';     def=0.08; hint='How gradually detail fades outside it. 0 = the old hard edge'},
  @{k='fovBitFocus';       n='Bit focus';            u='';     min=-6;   max=12;   step=1;    sc=1;   kind='fov';     def=0;    hint='+ = compress the edges harder so where you look gets more data. 0 = even'},
  @{k='calibYawDeg';       n='Turn';                 u='deg';  min=-20;  max=20;   step=0.5;  sc=10;  kind='calib';   def=0;    hint='Rotates the base-station world around you (left / right)'},
  @{k='calibXcm';          n='Shift left / right';   u='cm';   min=-30;  max=30;   step=0.5;  sc=10;  kind='calib';   def=0;    hint='+ moves the controllers to your right'},
  @{k='calibYcm';          n='Shift up / down';      u='cm';   min=-30;  max=30;   step=0.5;  sc=10;  kind='calib';   def=0;    hint='+ moves the controllers up'},
  @{k='calibZcm';          n='Shift forward / back'; u='cm';   min=-30;  max=30;   step=0.5;  sc=10;  kind='calib';   def=0;    hint='+ moves the controllers toward your back'}
)
$vr = (Get-Vr).driver_gazedot; $lv = Read-KV $live
$script:lighthouse = ($vr.PSObject.Properties.Name -contains 'trackingMode') -and ($vr.trackingMode -eq 'lighthouse')
$script:useIndex = $script:lighthouse -and -not (($vr.PSObject.Properties.Name -contains 'controllers') -and ($vr.controllers -eq 'pimax'))
$script:startLighthouse = $script:lighthouse
foreach ($d in $defs) { $v = $d.def
  if ($vr.PSObject.Properties.Name -contains $d.k) { $v = [double]$vr.($d.k) }
  if ($lv.ContainsKey($d.k)) { $v = [double]$lv[$d.k] }
  if ($d.ms -and $v -lt 1) { $v = $v * 1000 }
  if ($d.pct -and $v -le 2) { $v = $v * 100 }
  $d.val = [double]$v }

# ---- look
$bg = [System.Drawing.Color]::FromArgb(26,23,23); $panel = [System.Drawing.Color]::FromArgb(40,34,34)
$fg = [System.Drawing.Color]::FromArgb(240,160,90); $dim = [System.Drawing.Color]::FromArgb(185,120,85)
$accent = [System.Drawing.Color]::FromArgb(225,85,75); $hot = [System.Drawing.Color]::FromArgb(255,225,150); $good = [System.Drawing.Color]::FromArgb(140,220,140)
$form = New-Object System.Windows.Forms.Form
$form.Text = 'LoominLink Control'; $form.Size = New-Object System.Drawing.Size(680, 950); $form.StartPosition = 'CenterScreen'
$form.BackColor = $bg; $form.ForeColor = $fg; $form.Font = New-Object System.Drawing.Font('Segoe UI', 9.5); $form.FormBorderStyle = 'FixedSingle'; $form.MaximizeBox = $false
$title = New-Object System.Windows.Forms.Label; $title.Text = 'LoominLink'; $title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 18); $title.ForeColor = $accent; $title.Location = '20,22'; $title.AutoSize = $true; $form.Controls.Add($title)
$logoPath = Join-Path $PSScriptRoot 'LoominLink_logo3.png'
if (Test-Path $logoPath) { $pic = New-Object System.Windows.Forms.PictureBox; $pic.Image = [System.Drawing.Image]::FromFile($logoPath); $pic.SizeMode = 'Zoom'; $pic.Location = '585,6'; $pic.Size = '56,90'; $form.Controls.Add($pic)
  $form.Icon = [System.Drawing.Icon]::FromHandle(([System.Drawing.Bitmap]$pic.Image).GetHicon()) }
$stat = New-Object System.Windows.Forms.Label; $stat.Location = '20,98'; $stat.Size = '625,48'; $stat.BackColor = $panel; $stat.Font = New-Object System.Drawing.Font('Consolas', 10); $stat.Text = 'Waiting for SteamVR...'; $form.Controls.Add($stat)

# ---- tabs (owner-drawn so they match the dark theme)
$tabs = New-Object System.Windows.Forms.TabControl; $tabs.Location = '14,154'; $tabs.Size = '640,750'; $tabs.DrawMode = 'OwnerDrawFixed'; $tabs.ItemSize = '140,30'; $tabs.SizeMode = 'Fixed'
$tabs.Add_DrawItem({ param($s, $e) $sel = ($e.Index -eq $s.SelectedIndex); $b = New-Object System.Drawing.SolidBrush ($(if ($sel) { $accent } else { $panel }))
  $e.Graphics.FillRectangle($b, $e.Bounds); $tb2 = New-Object System.Drawing.SolidBrush ($(if ($sel) { [System.Drawing.Color]::FromArgb(26,23,23) } else { $fg }))
  $sf = New-Object System.Drawing.StringFormat; $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
  $e.Graphics.DrawString($s.TabPages[$e.Index].Text, (New-Object System.Drawing.Font('Segoe UI Semibold', 10)), $tb2, [System.Drawing.RectangleF]$e.Bounds, $sf) })
$pgSet = New-Object System.Windows.Forms.TabPage; $pgSet.Text = 'Settings'; $pgSet.BackColor = $bg; $pgSet.ForeColor = $fg
$pgCal = New-Object System.Windows.Forms.TabPage; $pgCal.Text = 'Calibration'; $pgCal.BackColor = $bg; $pgCal.ForeColor = $fg
$pgTrk = New-Object System.Windows.Forms.TabPage; $pgTrk.Text = 'Tracking'; $pgTrk.BackColor = $bg; $pgTrk.ForeColor = $fg
$pgFov = New-Object System.Windows.Forms.TabPage; $pgFov.Text = 'Foveation'; $pgFov.BackColor = $bg; $pgFov.ForeColor = $fg
$pgFan = New-Object System.Windows.Forms.TabPage; $pgFan.Text = 'Experimental'; $pgFan.BackColor = $bg; $pgFan.ForeColor = $fg
$tabs.ItemSize = '124,30'
$tabs.TabPages.Add($pgSet); $tabs.TabPages.Add($pgFov); $tabs.TabPages.Add($pgTrk); $tabs.TabPages.Add($pgCal); $tabs.TabPages.Add($pgFan); $form.Controls.Add($tabs)

$rows = @(); $script:changed = @{}
function Add-Header($parent, $text, $y) { $h = New-Object System.Windows.Forms.Label; $h.Text = $text; $h.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11); $h.ForeColor = $accent; $h.Location = "10,$y"; $h.AutoSize = $true; $parent.Controls.Add($h) }
function Fmt($row) { $d = $row.d; $v = $row.tb.Value / $d.sc
  if ($d.k -eq 'heatGuardC' -and $v -eq 0) { return 'off' }
  if ($d.k -eq 'decoderGuardMs' -and $v -eq 0) { return 'off' }
  if ($d.sc -eq 100) { return ('{0:0.00}' -f $v) + $d.u }
  if ($d.sc -eq 10) { return ('{0:0.0} ' -f $v) + $d.u }
  return ('{0} ' -f $v) + $d.u }
function Snap($row) { $s = [int][math]::Round($row.d.step * $row.d.sc); if ($s -gt 1) { $v = [int]([math]::Round(($row.tb.Value - $row.tb.Minimum) / $s) * $s + $row.tb.Minimum); $v = [math]::Max($row.tb.Minimum, [math]::Min($row.tb.Maximum, $v)); if ($row.tb.Value -ne $v) { $row.tb.Value = $v } } }
function New-Small($parent, $text, $x, $y) { $b = New-Object System.Windows.Forms.Button; $b.Text = $text; $b.Location = "$x,$y"; $b.Size = '28,26'; $b.FlatStyle = 'Flat'; $b.BackColor = $panel; $b.ForeColor = $fg; $b.FlatAppearance.BorderColor = $accent; $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10); $parent.Controls.Add($b); return $b }
function Add-Row($parent, $d, $y) {
  $lbl = New-Object System.Windows.Forms.Label; $lbl.Text = $d.n; $lbl.Location = "12,$($y+3)"; $lbl.Size = '160,20'; $parent.Controls.Add($lbl)
  $minus = New-Small $parent '-' 172 $y
  $tb = New-Object System.Windows.Forms.TrackBar; $tb.Location = "202,$($y-2)"; $tb.Size = '300,30'; $tb.TickStyle = 'None'; $tb.BackColor = $bg; $tb.AutoSize = $false
  $tb.Minimum = [int][math]::Round($d.min * $d.sc); $tb.Maximum = [int][math]::Round($d.max * $d.sc)
  $tb.SmallChange = [int][math]::Round($d.step * $d.sc); $tb.LargeChange = $tb.SmallChange   # one click on the track = one step (no jumping to the ends)
  $iv = [int][math]::Round($d.val * $d.sc); $tb.Value = [math]::Max($tb.Minimum, [math]::Min($tb.Maximum, $iv)); $parent.Controls.Add($tb)
  $plus = New-Small $parent '+' 504 $y
  $val = New-Object System.Windows.Forms.Label; $val.Location = "536,$($y+3)"; $val.Size = '80,20'; $val.TextAlign = 'MiddleRight'; $val.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10); $parent.Controls.Add($val)
  $hint = New-Object System.Windows.Forms.Label; $hint.Text = $d.hint; $hint.ForeColor = $dim; $hint.Font = New-Object System.Drawing.Font('Segoe UI', 8.5); $hint.Location = "12,$($y+27)"; $hint.Size = '600,16'; $parent.Controls.Add($hint)
  $row = @{d=$d; tb=$tb; val=$val}; $tb.Tag = $row; $minus.Tag = $row; $plus.Tag = $row; $val.Text = Fmt $row
  $tb.Add_ValueChanged({ param($s, $e) $rr = $s.Tag; Snap $rr; $rr.val.Text = Fmt $rr
     if ($rr.d.kind -eq 'calib' -or $rr.d.kind -eq 'ctrl' -or $rr.d.kind -eq 'fov') { Save-All | Out-Null; if ($rr.d.kind -eq 'fov') { Draw-Fov } } else { $rr.val.ForeColor = $hot; $script:changed[$rr.d.k] = $true } })
  $minus.Add_Click({ param($s, $e) $rr = $s.Tag; $rr.tb.Value = [math]::Max($rr.tb.Minimum, $rr.tb.Value - $rr.tb.SmallChange) })
  $plus.Add_Click({ param($s, $e) $rr = $s.Tag; $rr.tb.Value = [math]::Min($rr.tb.Maximum, $rr.tb.Value + $rr.tb.SmallChange) })
  return $row }

# ---- settings tab
$y = 10; Add-Header $pgSet 'Live - press Update, applies within a second' $y; $y += 30
foreach ($d in ($defs | Where-Object { $_.kind -eq 'live' })) { $rows += Add-Row $pgSet $d $y; $y += 50 }
$y += 4; Add-Header $pgSet 'Needs a SteamVR restart' $y; $y += 30
foreach ($d in ($defs | Where-Object { $_.kind -eq 'restart' })) { $rows += Add-Row $pgSet $d $y; $y += 50 }
function New-Btn($parent, $text, $x, $y, $w) { $b = New-Object System.Windows.Forms.Button; $b.Text = $text; $b.Location = "$x,$y"; $b.Size = "$w,36"; $b.FlatStyle = 'Flat'; $b.BackColor = $panel; $b.ForeColor = $fg; $b.FlatAppearance.BorderColor = $accent; $parent.Controls.Add($b); return $b }
$btnUpdate  = New-Btn $pgSet 'Update' 10 ($y+6) 180; $btnUpdate.BackColor = [System.Drawing.Color]::FromArgb(120,40,36)
$btnRestart = New-Btn $pgSet 'Update + restart SteamVR' 200 ($y+6) 220
$btnDefault = New-Btn $pgSet 'Defaults' 430 ($y+6) 186
$msg = New-Object System.Windows.Forms.Label; $msg.Location = "12,$($y+48)"; $msg.Size = '600,20'; $msg.ForeColor = $dim; $pgSet.Controls.Add($msg)


# ---- foveation tab
function FovIb([double]$x, [double]$h, [double]$G) {
  if ($x -le -$h - $G) { return 0.0 }
  if ($x -lt -$h) { $t = ($x + $h + $G) / $G; return $G * ($t*$t*$t - 0.5*$t*$t*$t*$t) }
  if ($x -le $h) { return 0.5*$G + ($x + $h) }
  if ($x -lt $h + $G) { $t = ($x - $h) / $G; return 0.5*$G + 2*$h + $G * ($t - $t*$t*$t + 0.5*$t*$t*$t*$t) }
  return $G + 2*$h }
function FovBump([double]$x, [double]$h, [double]$G) { $x = [math]::Abs($x); if ($x -le $h) { return 1.0 }; if ($G -lt 1e-3 -or $x -ge $h + $G) { return 0.0 }; $t = ($x - $h) / $G; return 1 - $t*$t*(3 - 2*$t) }
function FovAxis([double]$frac, [double]$grad, [double]$ratio) {   # same fit as the driver, looking straight ahead (W = 1)
  $h = $frac / 2; $G = $grad; $h0 = $h
  for ($i = 0; $i -lt 40; $i++) { $A = (FovIb (0.5) $h $G) - (FovIb (-0.5) $h $G); $m = if ($A -lt 0.999) { ($ratio - $A) / (1 - $A) } else { 0 }
    if ($m -ge 0.10 -or $h -lt 0.002) { break }; $h *= 0.93; $G *= 0.93 }
  return @{h=$h; G=$G; m=[math]::Max(0.02, [math]::Min(1.0, [double]$m)); fit=($h / [math]::Max($h0, 1e-6))} }
$fy = 10; Add-Header $pgFov 'Foveated streaming - applies instantly' $fy; $fy += 28
$fovInfo = New-Object System.Windows.Forms.Label; $fovInfo.Location = "12,$fy"; $fovInfo.Size = '600,34'; $fovInfo.ForeColor = $dim
$fovInfo.Text = 'Full detail where you look, less towards the edges. Soft edge blends the two so there is no visible line; width/height set the shape.'; $pgFov.Controls.Add($fovInfo); $fy += 40
$fovPic = New-Object System.Windows.Forms.PictureBox; $fovPic.Location = "12,$fy"; $fovPic.Size = '180,180'; $fovPic.BorderStyle = 'FixedSingle'; $pgFov.Controls.Add($fovPic)
$fovLeg = New-Object System.Windows.Forms.Label; $fovLeg.Location = "204,$fy"; $fovLeg.Size = '410,180'; $fovLeg.ForeColor = $fg; $pgFov.Controls.Add($fovLeg)
$fy += 192
foreach ($d in ($defs | Where-Object { $_.kind -eq 'fov' })) { $rows += Add-Row $pgFov $d $fy; $fy += 50 }
$chkZones = New-Object System.Windows.Forms.CheckBox; $chkZones.Text = 'Show the zones in the headset while tuning (green = full detail, red tint = reduced)'; $chkZones.Location = "12,$fy"; $chkZones.Size = '600,24'; $chkZones.ForeColor = $fg; $pgFov.Controls.Add($chkZones); $fy += 34
$chkZones.Add_CheckedChanged({ Save-All | Out-Null })
$vv0 = $null; try { $vv0 = (Get-Vr).driver_gazedot } catch {}
$chkSmooth = New-Object System.Windows.Forms.CheckBox; $chkSmooth.Text = 'Smooth foveation (untick = old hard-edged version, to compare)'; $chkSmooth.Location = "12,$fy"; $chkSmooth.Size = '600,24'; $chkSmooth.ForeColor = $fg
$chkSmooth.Checked = -not ($vv0 -and $vv0.smoothFoveation -eq 0); $pgFov.Controls.Add($chkSmooth); $fy += 30
$chkSmooth.Add_CheckedChanged({ Save-All | Out-Null })
$chkQp = New-Object System.Windows.Forms.CheckBox; $chkQp.Text = 'Encoder bit-focus mode (needed for Bit focus; applies after SteamVR restart)'; $chkQp.Location = "12,$fy"; $chkQp.Size = '600,24'; $chkQp.ForeColor = $fg
$chkQp.Checked = ($vv0 -and $vv0.encoderBitFocus -eq 1); $pgFov.Controls.Add($chkQp); $fy += 34
$chkQp.Add_CheckedChanged({ Save-All | Out-Null; $msg.Text = 'Encoder bit-focus mode changes after "Update + restart SteamVR" (Settings tab).'; $msg.ForeColor = $hot })
Add-Header $pgFov 'Presets' $fy; $fy += 28
function Set-Fov($w, $h, $g, $q) { foreach ($r in $rows) { switch ($r.d.k) { 'fovWidth' { $r.tb.Value = [int]($w*100) } 'fovHeight' { $r.tb.Value = [int]($h*100) } 'fovGradient' { $r.tb.Value = [int]($g*100) } 'fovBitFocus' { $r.tb.Value = $q } } }; Save-All | Out-Null; Draw-Fov }
$bp1 = New-Btn $pgFov 'Balanced' 10 $fy 116;       $bp1.Add_Click({ Set-Fov 0.30 0.30 0.08 0 })
$bp2 = New-Btn $pgFov 'Wide (sims)' 132 $fy 116;   $bp2.Add_Click({ Set-Fov 0.40 0.24 0.07 0 })
$bp3 = New-Btn $pgFov 'Extra soft' 254 $fy 116;    $bp3.Add_Click({ Set-Fov 0.22 0.22 0.16 0 })
$bp4 = New-Btn $pgFov 'Sharp focus' 376 $fy 116;   $bp4.Add_Click({ Set-Fov 0.30 0.30 0.08 6 })
$bp5 = New-Btn $pgFov 'Old hard edge' 498 $fy 116; $bp5.Add_Click({ Set-Fov 0.35 0.35 0.00 0 })
function Draw-Fov {
  $g = @{}; foreach ($r in $rows) { if ($r.d.kind -eq 'fov') { $g[$r.d.k] = $r.tb.Value / $r.d.sc } }
  $src = 2880.0; $out = 1280.0; try { $vv = (Get-Vr).driver_gazedot; if ($vv.eyeSource) { $src = [double]$vv.eyeSource }; if ($vv.eyeStream) { $out = [double]$vv.eyeStream } } catch {}
  $ratio = $out / $src; $ax = FovAxis $g['fovWidth'] $g['fovGradient'] $ratio; $ay = FovAxis $g['fovHeight'] $g['fovGradient'] $ratio
  $N = 180; $dx = New-Object double[] $N; $dy = New-Object double[] $N
  for ($i = 0; $i -lt $N; $i++) { $u = ($i + 0.5) / $N - 0.5; $dx[$i] = $ax.m + (1 - $ax.m) * (FovBump $u $ax.h $ax.G); $dy[$i] = $ay.m + (1 - $ay.m) * (FovBump $u $ay.h $ay.G) }
  $bmp = New-Object System.Drawing.Bitmap $N, $N
  $bd = $bmp.LockBits((New-Object System.Drawing.Rectangle 0, 0, $N, $N), 'WriteOnly', 'Format32bppArgb'); $px = New-Object byte[] ($bd.Stride * $N)
  for ($y = 0; $y -lt $N; $y++) { for ($x = 0; $x -lt $N; $x++) { $d = $dx[$x] * $dy[$y]; $o = $y * $bd.Stride + $x * 4
      $px[$o] = [byte](30 + 30*$d); $px[$o+1] = [byte](40 + 150*$d); $px[$o+2] = [byte](70 + 185*$d); $px[$o+3] = 255 } }
  [System.Runtime.InteropServices.Marshal]::Copy($px, 0, $bd.Scan0, $px.Length); $bmp.UnlockBits($bd)
  if ($fovPic.Image) { $fovPic.Image.Dispose() }; $fovPic.Image = $bmp
  $edge = [math]::Round(100 * $ax.m * $ay.m); $fit = [math]::Round(100 * [math]::Min($ax.fit, $ay.fit))
  $txt = "Detail map, looking straight ahead (bright = full detail).`r`n`r`nCorners keep about $edge% of full detail."
  if ($fit -lt 99) { $txt += "`r`n`r`nToo big for the stream size: the sharp area is shrunk to $fit% to fit. Make it smaller, use less soft edge, or raise Stream size (Settings tab)." ; $fovLeg.ForeColor = $hot } else { $fovLeg.ForeColor = $fg }
  $txt += "`r`n`r`nTip: tick 'Show the zones' and look around to see it live."
  $fovLeg.Text = $txt }

# ---- tracking tab
function New-Group($text, $y, $h) { $g = New-Object System.Windows.Forms.GroupBox; $g.Text = $text; $g.ForeColor = $accent; $g.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10.5); $g.Location = "10,$y"; $g.Size = "612,$h"; $pgTrk.Controls.Add($g); return $g }
function New-Radio($g, $text, $sub, $y) { $r = New-Object System.Windows.Forms.RadioButton; $r.Text = $text; $r.ForeColor = $fg; $r.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10); $r.Location = "16,$y"; $r.AutoSize = $true; $g.Controls.Add($r)
  $l = New-Object System.Windows.Forms.Label; $l.Text = $sub; $l.ForeColor = $dim; $l.Font = New-Object System.Drawing.Font('Segoe UI', 8.75); $l.Location = "36,$($y+24)"; $l.Size = '560,34'; $g.Controls.Add($l); return $r }
$gT = New-Group 'Tracking (needs a SteamVR restart)' 10 170
$rIn = New-Radio $gT 'Inside-out only' 'The headset cameras track everything. Play anywhere - no base stations needed. Uses the Pimax controllers.' 28
$rLh = New-Radio $gT 'Base stations (lighthouse)' 'Adds base-station devices: Index controllers and Vive trackers (full body). Needs a one-time calibration each session (Calibration tab).' 92
$gC = New-Group 'Controllers (applies instantly)' 192 170
$rPx = New-Radio $gC 'Pimax controllers' 'Use the Pimax controllers in your hands. With base stations, Vive trackers still work for full body.' 28
$rIx = New-Radio $gC 'Index controllers' 'Use Valve Index controllers (finger tracking). Requires base-station tracking - selecting this switches it on.' 92
$trkMsg = New-Object System.Windows.Forms.Label; $trkMsg.Location = '12,376'; $trkMsg.Size = '610,40'; $trkMsg.ForeColor = $dim; $pgTrk.Controls.Add($trkMsg)
$btnTrkRestart = New-Btn $pgTrk 'Restart SteamVR now' 10 420 220; $btnTrkRestart.Visible = $false; $btnTrkRestart.BackColor = [System.Drawing.Color]::FromArgb(120,40,36)
$ty = 466; Add-Header $pgTrk 'Pimax controller smoothing (applies instantly)' $ty; $ty += 30
foreach ($d in ($defs | Where-Object { $_.kind -eq 'ctrl' })) { $rows += Add-Row $pgTrk $d $ty; $ty += 50 }
$ctrlStat = New-Object System.Windows.Forms.Label; $ctrlStat.Location = "12,$($ty+2)"; $ctrlStat.Size = '410,36'; $ctrlStat.ForeColor = $dim; $pgTrk.Controls.Add($ctrlStat)
$btnCtrlDef = New-Btn $pgTrk 'Reset smoothing' 430 $ty 190
$btnCtrlDef.Add_Click({ foreach ($r in $rows) { if ($r.d.kind -eq 'ctrl') { $r.tb.Value = [int][math]::Round($r.d.def * $r.d.sc) } }; Save-All | Out-Null })
$rIn.Checked = -not $script:lighthouse; $rLh.Checked = $script:lighthouse; $rPx.Checked = -not $script:useIndex; $rIx.Checked = $script:useIndex
$script:trkInit = $true
function Update-Trk {
  if ($script:trkInit) { return }
  $script:lighthouse = $rLh.Checked; $script:useIndex = $rIx.Checked
  Save-All | Out-Null
  if ($script:lighthouse -ne $script:startLighthouse) { $trkMsg.Text = 'Tracking mode saved. It takes effect after a SteamVR restart (keep LoominLink open on the headset).'; $trkMsg.ForeColor = $hot; $btnTrkRestart.Visible = $true }
  else { $trkMsg.Text = $(if ($script:useIndex) { 'Index controllers in use - Pimax controllers hidden.' } else { 'Pimax controllers in use.' }); $trkMsg.ForeColor = $good; $btnTrkRestart.Visible = $false } }
$rIn.Add_CheckedChanged({ if ($rIn.Checked -and $rIx.Checked) { $rPx.Checked = $true }; Update-Trk })
$rLh.Add_CheckedChanged({ Update-Trk })
$rIx.Add_CheckedChanged({ if ($rIx.Checked -and -not $rLh.Checked) { $rLh.Checked = $true }; Update-Trk })
$rPx.Add_CheckedChanged({ Update-Trk })
$btnTrkRestart.Add_Click({ $script:startLighthouse = $script:lighthouse; $btnTrkRestart.Visible = $false; $trkMsg.Text = 'Restarting SteamVR...'; $trkMsg.ForeColor = $accent; $form.Refresh(); Restart-SteamVR })

# ---- calibration tab
$cy = 8
$calPath = Join-Path $PSScriptRoot 'LoominLink_calibrate2.png'
if (Test-Path $calPath) { $cp = New-Object System.Windows.Forms.PictureBox; $cp.Image = [System.Drawing.Image]::FromFile($calPath); $cp.SizeMode = 'Zoom'; $cp.Location = "8,$cy"; $cp.Size = '612,153'; $pgCal.Controls.Add($cp); $cy += 160 }
$steps = New-Object System.Windows.Forms.Label; $steps.Location = "10,$cy"; $steps.Size = '610,146'; $steps.ForeColor = $fg
$steps.Text = "Lines up the base stations (Index controllers, Vive trackers) with the headset's own tracking.`r`n" +
  "1. Turn on the RIGHT Pimax controller and the RIGHT Index controller (or a tracker).`r`n" +
  "2. Hold them side by side in one hand, gripped firmly so they can't slide.`r`n" +
  "3. Press Start calibration below (or hold A+B on the Pimax controller for 2 s). Two beeps = started.`r`n" +
  "4. For 15 s: turn them to a new angle, then HOLD STILL for about 1 second. Repeat ~8 times,`r`n" +
  "    mixing tilts (forward, back, left, right) and twists. Samples are only taken while still.`r`n" +
  "5. One long beep = saved. Three short beeps = try again with longer, steadier pauses.`r`n" +
  "Redo it after the headset app restarts (its tracking origin resets)."
$pgCal.Controls.Add($steps); $cy += 150
$btnCal = New-Btn $pgCal 'Start calibration' 10 $cy 200; $btnCal.BackColor = [System.Drawing.Color]::FromArgb(120,40,36)
$calStat = New-Object System.Windows.Forms.Label; $calStat.Location = "222,$($cy+8)"; $calStat.Size = '400,22'; $calStat.ForeColor = $dim; $pgCal.Controls.Add($calStat); $cy += 50
Add-Header $pgCal 'Fine-tune (applies instantly)' $cy; $cy += 30
foreach ($d in ($defs | Where-Object { $_.kind -eq 'calib' })) { $rows += Add-Row $pgCal $d $cy; $cy += 50 }
$btnCalReset = New-Btn $pgCal 'Reset fine-tune' 10 ($cy+4) 200
$btnCal.Add_Click({ try { Set-Content -Path $calTrigger -Value 'go'; $calStat.Text = 'Starting - listen for two beeps, then turn the controllers slowly...'; $calStat.ForeColor = $hot } catch { $calStat.Text = 'Could not start: ' + $_.Exception.Message } })
$btnCalReset.Add_Click({ foreach ($r in $rows) { if ($r.d.kind -eq 'calib') { $r.tb.Value = 0 } }; Save-All | Out-Null })

# ---- fan tab: the headset fan, over ADB (needs the rooted headset + the LoominLink fan module)
function Find-Adb {
  $c = @(); $w = Get-Command adb.exe -ErrorAction SilentlyContinue; if ($w) { $c += $w.Source }
  $c += (Join-Path $PSScriptRoot 'platform-tools\adb.exe'), (Join-Path (Split-Path $PSScriptRoot -Parent) 'platform-tools\adb.exe'),
        (Join-Path $env:LOCALAPPDATA 'LoominLink\platform-tools\adb.exe'), 'C:\platform-tools\adb.exe', (Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe')
  foreach ($p in $c) { if ($p -and (Test-Path $p)) { return $p } }; return $null }
$script:adb = Find-Adb
function Invoke-Adb([string]$argStr, [int]$ms = 6000) {
  if (-not $script:adb) { return $null }
  try {
    $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName = $script:adb; $psi.Arguments = $argStr
    $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true
    $p = [System.Diagnostics.Process]::Start($psi); $o = $p.StandardOutput.ReadToEndAsync(); $e = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit($ms)) { try { $p.Kill() } catch {}; return $null }
    return ($o.Result + $e.Result) } catch { return $null } }
function Get-Headset {
  $out = Invoke-Adb 'devices' 5000; if (-not $out) { return $null }
  $list = @(); foreach ($l in ($out -split "`r?`n")) { if ($l -match '^(\S+)\s+device\s*$') { $list += $matches[1] } }
  if ($list.Count -eq 0) { return $null }
  $usb = @($list | Where-Object { $_ -notmatch ':' }); if ($usb.Count -gt 0) { return $usb[0] }; return $list[0] }
function Fan-Cmd([string]$sub, [int]$ms = 6000) {
  $s = Get-Headset; if (-not $s) { return '#nodevice' }
  $r = Invoke-Adb ("-s $s shell ""su -c 'sh /data/adb/modules/loominlink_fan/fanctl.sh $sub'""") $ms
  if ($null -eq $r) { return '#timeout' }; return $r }
$fy = 8; Add-Header $pgFan 'Headset fan  (experimental - needs the rooted headset)' $fy; $fy += 28
$fanInfo = New-Object System.Windows.Forms.Label; $fanInfo.Location = "12,$fy"; $fanInfo.Size = '608,52'; $fanInfo.ForeColor = $dim
$fanInfo.Text = "Experimental: the fan can run from 5% to 99%; Pimax's own control stops around 20%. Needs the rooted headset with the LoominLink fan module. Sent over ADB (USB or Wi-Fi ADB) and kept on the headset - it keeps working with this window closed."
$pgFan.Controls.Add($fanInfo); $fy += 56
$gF = New-Object System.Windows.Forms.GroupBox; $gF.Text = 'Fan mode'; $gF.ForeColor = $accent; $gF.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10.5); $gF.Location = "10,$fy"; $gF.Size = '612,330'; $pgFan.Controls.Add($gF)
$rfStream = New-Radio $gF 'Boost while LoominLink runs  (recommended)' "Streaming speed (below) whenever the LoominLink app is open; Pimax's own control the rest of the time." 26
$rfCool   = New-Radio $gF 'Cooler curve' 'Follows the hottest chip: 35% at 60 C, rising to 99% at 85 C. Quiet when it can be, loud when it must.' 86
$rfMax    = New-Radio $gF 'Always 99%' 'Full speed all the time, also in the Pimax menu.' 146
$rfFixed  = New-Radio $gF 'Fixed speed' 'Uses the Fixed speed slider below.' 206
$rfStock  = New-Radio $gF 'Pimax default' "Hands the fan back to Pimax's own control (tops out around 20%)." 266
$fy += 340
function New-FanSlider($text, $min, $max, $val, $y) {
  $l = New-Object System.Windows.Forms.Label; $l.Text = $text; $l.Location = "12,$($y+6)"; $l.Size = '130,22'; $pgFan.Controls.Add($l)
  $t = New-Object System.Windows.Forms.TrackBar; $t.Minimum = $min; $t.Maximum = $max; $t.TickFrequency = 10; $t.SmallChange = 1; $t.LargeChange = 5; $t.Value = $val; $t.Location = "145,$y"; $t.Size = '370,40'; $t.BackColor = $bg; $pgFan.Controls.Add($t)
  $v = New-Object System.Windows.Forms.Label; $v.Location = "522,$($y+6)"; $v.Size = '90,22'; $v.ForeColor = $hot; $v.Text = "$val%"; $pgFan.Controls.Add($v)
  $t.Add_ValueChanged({ $v.Text = "$($t.Value)%" }.GetNewClosure())
  return @{ lbl = $l; tb = $t; val = $v } }
$fsStream = New-FanSlider 'Streaming speed' 25 99 70 $fy; $fy += 44
$fsFixed  = New-FanSlider 'Fixed speed' 5 99 50 $fy; $fy += 48
$btnFanApply = New-Btn $pgFan 'Apply to headset' 10 $fy 200; $btnFanApply.BackColor = [System.Drawing.Color]::FromArgb(120,40,36)
$btnFanRefresh = New-Btn $pgFan 'Refresh' 220 $fy 110; $fy += 46
$fanStat = New-Object System.Windows.Forms.Label; $fanStat.Location = "12,$fy"; $fanStat.Size = '608,70'; $fanStat.BackColor = $panel; $fanStat.Font = New-Object System.Drawing.Font('Consolas', 10); $fanStat.Text = '  Open this tab to read the fan.'; $pgFan.Controls.Add($fanStat)
function Update-FanUi {
  $fsStream.tb.Enabled = $rfStream.Checked; $fsStream.lbl.ForeColor = $(if ($rfStream.Checked) { $fg } else { $dim })
  $fsFixed.tb.Enabled = $rfFixed.Checked;   $fsFixed.lbl.ForeColor  = $(if ($rfFixed.Checked) { $fg } else { $dim }) }
foreach ($r in @($rfStream, $rfCool, $rfMax, $rfFixed, $rfStock)) { $r.Add_CheckedChanged({ Update-FanUi }) }
$script:fanLoaded = $false
function Show-Fan([string]$out) {
  if (-not $script:adb) { $fanStat.Text = "  ADB not found (Google platform-tools)."; $fanStat.ForeColor = $dim; return }
  if ($out -eq '#nodevice') { $fanStat.Text = "  No headset over ADB.`r`n  Plug in the USB cable (or set up Wi-Fi ADB)."; $fanStat.ForeColor = $dim; return }
  if ($out -eq '#timeout') { $fanStat.Text = '  The headset did not answer in time - try Refresh.'; $fanStat.ForeColor = $hot; return }
  if ($out -match 'Permission denied|not allowed') { $fanStat.Text = "  Root was refused. In the Magisk app, allow Shell`r`n  (Superuser list)."; $fanStat.ForeColor = $hot; return }
  if ($out -match "can't open|No such file|inaccessible or not found") { $fanStat.Text = "  The fan module is not installed on the headset yet.`r`n  Run the fan module installer once."; $fanStat.ForeColor = $hot; return }
  $k = @{}; foreach ($l in ($out -split "`r?`n")) { if ($l -match '^\s*(\w+)\s*=\s*(.*?)\s*$') { $k[$matches[1]] = $matches[2] } }
  if ($k['daemon'] -ne 'running') { $fanStat.Text = "  The fan service is not running on the headset.`r`n  Reboot the headset; if it stays off, re-run the installer."; $fanStat.ForeColor = $hot; return }
  if (-not $k.ContainsKey('duty')) { $fanStat.Text = "  The headset has the old fan module (v1).`r`n  Run tools\Install fan control (rooted headset).bat"; $fanStat.ForeColor = $hot; return }
  $who = $(if ($k['control'] -eq '1') { 'LoominLink is driving it' } else { "Pimax's own control" })
  $app = $(if ($k['app'] -eq '1') { 'open' } else { 'closed' })
  $fanStat.Text = "  Fan $($k['duty'])%   - $who`r`n  Hottest chip $($k['soc']) C    skin $($k['skin']) C    LoominLink app: $app"
  $fanStat.ForeColor = $(if ([int]$k['soc'] -ge 90 -or [int]$k['skin'] -ge 60) { [System.Drawing.Color]::FromArgb(255,170,80) } else { $good })
  if (-not $script:fanLoaded) { $script:fanLoaded = $true
    switch ($k['mode']) { 'cool' { $rfCool.Checked = $true } 'max' { $rfMax.Checked = $true } 'fixed' { $rfFixed.Checked = $true } 'stock' { $rfStock.Checked = $true } default { $rfStream.Checked = $true } }
    if ($k['level'] -match '^\d+$')  { $fsFixed.tb.Value  = [math]::Max(5,  [math]::Min(99, [int]$k['level'])) }
    if ($k['stream'] -match '^\d+$') { $fsStream.tb.Value = [math]::Max(25, [math]::Min(99, [int]$k['stream'])) }
    Update-FanUi } }
$btnFanApply.Add_Click({
  $m = $(if ($rfCool.Checked) { 'cool' } elseif ($rfMax.Checked) { 'max' } elseif ($rfFixed.Checked) { 'fixed' } elseif ($rfStock.Checked) { 'stock' } else { 'stream' })
  $fanStat.Text = '  Sending to the headset...'; $fanStat.ForeColor = $hot; $form.Refresh()
  $script:fanLoaded = $true; Show-Fan (Fan-Cmd "set $m $($fsFixed.tb.Value) $($fsStream.tb.Value)" 14000) })
$btnFanRefresh.Add_Click({ $fanStat.Text = '  Reading...'; $form.Refresh(); Show-Fan (Fan-Cmd 'status') })
$tabs.Add_SelectedIndexChanged({ if ($tabs.SelectedTab -eq $pgFan) { $fanStat.Text = '  Reading...'; $form.Refresh(); Show-Fan (Fan-Cmd 'status') } })
$fanTimer = New-Object System.Windows.Forms.Timer; $fanTimer.Interval = 5000
$fanTimer.Add_Tick({ if ($tabs.SelectedTab -eq $pgFan -and $form.ContainsFocus) { Show-Fan (Fan-Cmd 'status' 4000) } })
$fanTimer.Start()
$rfStream.Checked = $true; Update-FanUi

function Save-All {
  $j = Get-Vr; $dd = $j.driver_gazedot; $liveLines = @(); $needRestart = $false
  foreach ($r in $rows) { $d = $r.d; $v = $r.tb.Value / $d.sc; $store = $v; if ($d.ms) { $store = $v / 1000.0 }; if ($d.pct) { $store = $v / 100.0 }
    $sv = ([string]$store).Replace(',', '.')
    if ($d.kind -ne 'restart') { $liveLines += ('{0}={1}' -f $d.k, $sv) }
    if ($d.kind -ne 'calib' -and $d.k -ne 'displayPredictMs') { $dd | Add-Member -NotePropertyName $d.k -NotePropertyValue ([double]$store) -Force }
    if ($d.kind -eq 'restart' -and $script:changed.ContainsKey($d.k)) { $needRestart = $true }
    if ($d.kind -ne 'calib') { $r.val.ForeColor = $fg } }
  $dd | Add-Member -NotePropertyName trackingMode -NotePropertyValue $(if ($script:lighthouse) { 'lighthouse' } else { 'inside-out' }) -Force
  $dd | Add-Member -NotePropertyName controllers -NotePropertyValue $(if ($script:useIndex) { 'index' } else { 'pimax' }) -Force
  $liveLines += ('useIndexControllers={0}' -f $(if ($script:useIndex) { 1 } else { 0 }))
  $liveLines += ('fovShowZones={0}' -f $(if ($chkZones.Checked) { 1 } else { 0 }))
  $liveLines += ('smoothFoveation={0}' -f $(if ($chkSmooth.Checked) { 1 } else { 0 }))
  $dd | Add-Member -NotePropertyName smoothFoveation -NotePropertyValue $(if ($chkSmooth.Checked) { 1 } else { 0 }) -Force
  $dd | Add-Member -NotePropertyName encoderBitFocus -NotePropertyValue $(if ($chkQp.Checked) { 1 } else { 0 }) -Force
  $j | ConvertTo-Json -Depth 5 | Set-Content $vrs -Encoding UTF8
  $liveLines | Set-Content $live -Encoding ASCII
  $script:changed = @{}
  return $needRestart }
function Restart-SteamVR { Stop-Process -Name vrserver,vrmonitor,vrcompositor -Force -ErrorAction SilentlyContinue; Start-Sleep 3; Start-Process 'steam://run/250820' }
$btnUpdate.Add_Click({ $nr = Save-All; if ($nr) { $msg.Text = 'Live settings applied. Margin/render/stream need "Update + restart SteamVR".'; $msg.ForeColor = $hot } else { $msg.Text = 'Applied - you should see it within a second.'; $msg.ForeColor = $good } })
$btnRestart.Add_Click({ Save-All | Out-Null; $msg.Text = 'Saved - restarting SteamVR (keep LoominLink open on the headset)...'; $msg.ForeColor = $accent; $form.Refresh(); Restart-SteamVR })
$btnDefault.Add_Click({ foreach ($r in $rows) { if ($r.d.kind -ne 'calib') { $r.tb.Value = [int][math]::Round($r.d.def * $r.d.sc) } }; $msg.Text = 'Defaults loaded - press Update to apply.'; $msg.ForeColor = $dim })

$script:trkInit = $false
Draw-Fov
# ---- status, once a second
$timer = New-Object System.Windows.Forms.Timer; $timer.Interval = 1000
$timer.Add_Tick({
  $s = Read-KV $status; $age = 99
  if (Test-Path $status) { $age = ((Get-Date) - (Get-Item $status).LastWriteTime).TotalSeconds }
  if ($age -gt 5) { $stat.Text = "  Not streaming (SteamVR or the headset is off)"; $stat.ForeColor = $dim; $calStat.Text = 'Start SteamVR and the headset app first.'; return }
  $conn = if ($s['connected'] -eq '1') { 'Connected' } else { 'Waiting for headset' }
  $t = [int]$s['headsetTempC']; $tg = [int]$s['heatGuardC']
  $br = "$($s['bitrateMbps']) Mbps"
  if ($s['bitrateMbps'] -ne $s['userBitrateMbps']) { $why = if ([int]$s['decoderCap'] -gt 0) { 'decoder guard' } else { 'heat guard' }; $br += " ($why, set $($s['userBitrateMbps']))" }
  if ($s['decodeMs']) { $br += "   decode $($s['decodeMs']) ms" }
  if ($s['micQueueMs']) { $br += "   mic $($s['micQueueMs']) ms" }
  $stat.Text = "  $conn   $($s['fps']) fps   encode $($s['encodeMs']) ms`r`n  $br   headset $t C"
  $stat.ForeColor = $(if ($tg -gt 0 -and $t -ge $tg) { [System.Drawing.Color]::FromArgb(255,170,80) } else { $fg })
  $cl = if ($s['ctrlLeft'] -eq '1') { 'on' } else { 'off' }; $cr = if ($s['ctrlRight'] -eq '1') { 'on' } else { 'off' }
  $ctrlStat.Text = "Pimax controllers: left $cl, right $cr`r`nWi-Fi delay wobble $($s['ctrlJitterMs']) ms (compensated)"
  if ($s['bitFocusOk'] -eq '0') { $fovInfo.Text = 'Bit focus is inactive: tick "Encoder bit-focus mode" below and restart SteamVR to use it.' }
  if ($s['lighthouse'] -ne '1') { $calStat.Text = 'Tracking mode is inside-out - calibration is only needed in lighthouse mode.'; $calStat.ForeColor = $dim }
  elseif ($s['calibrating'] -eq '1') { $calStat.Text = 'Calibrating... new angle, hold still 1 s, repeat'; $calStat.ForeColor = $hot }
  elseif ($s['calibErrCm'] -eq '-2.0') { $calStat.Text = 'Last calibration failed - try again, turning more slowly'; $calStat.ForeColor = [System.Drawing.Color]::FromArgb(255,120,100) }
  elseif ($s['calibrated'] -eq '1') { $e2 = $s['calibErrCm']; $calStat.Text = $(if ([double]$e2 -gt 0) { "Calibrated (error $e2 cm)" } else { 'Calibrated' }); $calStat.ForeColor = $good }
  else { $calStat.Text = 'Not calibrated yet'; $calStat.ForeColor = $hot }
})
$timer.Start()
[void]$form.ShowDialog()
} catch { [System.Windows.Forms.MessageBox]::Show("LoominLink Control hit an error:`r`n$($_.Exception.Message)`r`n$($_.InvocationInfo.PositionMessage)", 'LoominLink Control') | Out-Null }
