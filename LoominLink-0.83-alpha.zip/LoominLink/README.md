# LoominLink (alpha)

Wireless, eye-tracked **foveated** SteamVR streaming for the **Pimax Crystal (original)** in standalone (all-in-one) mode.

The PC renders the game, LoominLink sends a compressed video over Wi-Fi with full detail where your eyes are looking (using the Crystal's eye tracking) and less towards the edges, and the headset shows it with its own head tracking and lens correction.

> **Experimental test build.** Expect bugs and crashes. Not affiliated with, endorsed by, or supported by Pimax or Valve. Use at your own risk.

**New here? Open `START HERE.txt` for the step-by-step guide.**

## What's new in 0.83

- **Smoother at low game frame rates:** the headset now shows each frame the moment it is decoded. Before, a frame waited for the next frame's data, which added up to a whole frame of delay and uneven timing when a game ran below 90 fps, and made the decoder guard lower the bitrate for no reason.
- **Experimental fan control** for headsets rooted with Magisk: the fan can run at up to 99% instead of Pimax's ~20%. New **Experimental** tab in LoominLink Control. See below.
- Installer: one USB session (and one headset reboot) for the app and fan control; the bug-report logs now include the fan status.

## What you need

| | |
|---|---|
| Headset | Pimax Crystal (original / "OG") in standalone mode, plus a USB data cable to install the headset app |
| PC | Windows 10/11, **NVIDIA GPU** (uses NVENC HEVC), SteamVR installed |
| Network | A good 5 GHz / 6 GHz router; the PC **wired** to the router; headset on the same network |
| Optional | [VB-Audio Virtual Cable](https://vb-audio.com/Cable/) to use the headset microphone on the PC |
| Optional | SteamVR base stations + Index controllers / Vive trackers (one USB dongle per device on the PC) |

### USB connection (ADB)

The installer puts the headset app on the Crystal over a USB cable using ADB. On the Crystal's system software tested so far, ADB is already enabled, so there is nothing to switch on:

1. Turn the headset on and plug it into the PC with a USB data cable.
2. If the headset shows an **"Allow USB debugging?"** prompt, put it on and accept it (tick "Always allow from this computer").
3. If the installer still can't find the headset, try another cable or USB port. Some cables only charge.

## Install

1. Unzip anywhere.
2. Double-click **`Install LoominLink.bat`** and follow the prompts. It:
   - copies LoominLink to `%LOCALAPPDATA%\LoominLink`
   - registers the SteamVR driver and sets SteamVR to use it (your `steamvr.vrsettings` is backed up as `steamvr.vrsettings.loominlink-backup`)
   - adds Windows Firewall rules so the headset can find the PC (asks for admin)
   - adds a **LoominLink Control** shortcut to the Desktop and Start menu
   - optionally installs the headset app over USB (downloads Google's ADB tools if you don't have them)
   - optionally installs the experimental fan control (rooted headsets only - answer No if unsure)
3. After installing the headset app, the headset reboots. This is intentional: streaming right after a USB/ADB session can crash the headset.

Updating: run the new version's installer. Your LoominLink settings are kept.

## Play

1. In the headset, open **LoominLink** from the Pimax library. A waiting screen explains what to do (and how to get back to Pimax home).
2. Start **SteamVR** on the PC. The headset connects automatically.
3. Open **LoominLink Control** on the PC to tune settings while you play.

## LoominLink Control

- **Settings:** bitrate, frames in flight, prediction, heat guard, decoder guard, mic delay; plus stream/render size (needs a SteamVR restart).
- **Foveation:** shape (width/height) and soft edge of the full-detail area, with a preview, presets and a "show zones" overlay.
- **Tracking:** Pimax controllers or Index controllers, inside-out or base-station (lighthouse) tracking, Pimax controller smoothing.
- **Experimental:** headset fan control (rooted headsets only, see below).
- **Calibration:** aligns the headset's tracking with base-station space (for trackers / Index controllers). Hold the right Pimax controller firmly together with a lighthouse device (right Index controller, or a Vive tracker with the others switched off), start calibration, then turn them to ~8 different angles, pausing ~1 s at each.

## Known issues (please read)

- **Keep Bitrate at 120 Mbps or lower.** Higher bitrates can overwhelm the headset's video decoder and crash the headset.
- **Heat / battery:** on long wireless sessions the battery gets hot (the headset draws about 12 W). Around 50 C the headset lowers its screen to 72 Hz by itself, which shows up as stutter that stays until it cools down. The best fix is a USB-C power bank in the headset's charging port (top right, the one used for installing): Quick Charge 3.0 output, 25 W or more. The heat guard also lowers the bitrate when the headset is hot.
- **Heavy games stutter (VRChat etc.):** usually the PC can't render 90 fps at the default render size. Lower **Render size per eye** to about 2400 (Settings tab, needs a SteamVR restart).
- **Crashes:** the headset sometimes crashes (and may need a full power-off afterwards). If it crashes repeatedly within seconds, power it fully off for 30 s.
- **Lighthouse faceplate:** in standalone mode the headset cannot use the faceplate, so base-station tracking of the headset itself is not available; controllers/trackers need their own USB dongles on the PC.
- "Encoder bit-focus mode" (Foveation tab) is off by default; it may cause crashes on this headset.

## Fan control (experimental, rooted headsets only)

Pimax's own fan control runs the headset fan at about 20% at most; the fan driver itself accepts 5-99%. On a headset **rooted with Magisk**, LoominLink can install a small Magisk module that uses the full range:

- **Boost while LoominLink runs** (default, 70%, adjustable 25-99%), Pimax's own control the rest of the time
- **Cooler curve** (35% at 60 C up to 99% at 85 C on the hottest chip), **Always 99%**, **Fixed speed**, or **Pimax default**
- Safety: any setting jumps to 99% if a chip reaches 90 C or the skin sensor 60 C; if the service stops, the fan goes back to Pimax's control

Install: allow root for **Shell** in the Magisk app, then run `tools\Install fan control (rooted headset).bat` (or answer y in the installer). Change the mode on the **Experimental** tab of LoominLink Control (needs the USB cable while you change it; the setting is kept on the headset).

Rooting is **not** part of LoominLink and is not explained here. It can brick the headset; do it only if you know how to recover it.

## Reporting a problem

Run **`tools\Save logs for a bug report.bat`** right after the problem (don't restart the headset first). It saves a zip on your Desktop with serial numbers, MAC and IP addresses removed. Please still look through it before posting it publicly.

## Uninstall

Double-click **`Uninstall LoominLink.bat`**. It removes the driver, restores SteamVR's normal headset selection, removes the firewall rules and shortcuts, and can remove the headset app (and fan control, if installed).

## License

LoominLink is free to use during the open beta, but it is **not open source**: modifying, redistributing or reverse engineering it is not allowed. See [LICENSE.txt](LICENSE.txt).

Only download LoominLink from the official release page. The installer checks its files and refuses to install a modified copy. To check a download yourself, compare its SHA-256 (`Get-FileHash LoominLink-0.83-alpha.zip` in PowerShell) with the one on the release page.

## Version

0.83-alpha: headset app 0.83, SteamVR driver v43, LoominLink Control v17, fan module v2.
