#!/system/bin/sh
# LoominLink fan control v2:
#   fanctl.sh set <stock|stream|max|cool|fixed> [fixed% 5-99] [stream% 5-99] | status | start | stop | log
D=/data/adb/loominlink
M=${0%/*}
alive() { p=$(cat $D/fand.pid 2>/dev/null); [ -n "$p" ] && [ -d /proc/$p ] && grep -q fand /proc/$p/cmdline 2>/dev/null; }
num() { v=$1; case "$v" in ''|*[!0-9]*) v=$2;; esac; echo $v; }
case "$1" in
  set)
    case "$2" in stock|stream|max|cool|fixed) ;; *) echo "error=unknown mode '$2'"; exit 1;; esac
    l=$(num "$3" 50); s=$(num "$4" 70)
    mkdir -p $D
    printf 'mode=%s\nlevel=%s\nstream=%s\n' "$2" "$l" "$s" > $D/fan.conf.tmp && mv $D/fan.conf.tmp $D/fan.conf
    sh $0 start >/dev/null 2>&1
    sleep 3
    sh $0 status ;;
  status)
    if alive; then cat $D/fan_status 2>/dev/null; else echo "daemon=stopped"; fi ;;
  start)
    if alive; then echo "already running"; exit 0; fi
    ( setsid sh $M/fand.sh </dev/null >/dev/null 2>&1 & ) 2>/dev/null
    sleep 1
    if ! alive; then ( nohup sh $M/fand.sh </dev/null >/dev/null 2>&1 & ); sleep 1; fi
    if alive; then echo "started"; else echo "error=could not start"; fi ;;
  stop)
    p=$(cat $D/fand.pid 2>/dev/null); [ -n "$p" ] && kill $p 2>/dev/null
    for i in 1 2 3 4; do alive || break; sleep 1; done; echo "stopped" ;;
  log) tail -n 30 $D/fand.log 2>/dev/null ;;
  *) echo "usage: fanctl.sh set <stock|stream|max|cool|fixed> [fixed%] [stream%] | status | start | stop | log" ;;
esac
