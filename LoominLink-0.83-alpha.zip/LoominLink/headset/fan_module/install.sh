#!/system/bin/sh
# Run as root from /data/local/tmp/llfan: puts the module in place (Magisk starts it every boot).
S=${0%/*}
M=/data/adb/modules/loominlink_fan
echo "### magisk"
magisk -v
if [ -x /data/adb/magisk/busybox ]; then echo "magisk_env=ok"
else echo "magisk_env=MISSING - Magisk's 'additional setup' hasn't been done, so boot scripts won't run yet"; fi
[ -f $M/fanctl.sh ] && sh $M/fanctl.sh stop
mkdir -p $M
for f in module.prop service.sh uninstall.sh fand.sh fanctl.sh; do cp -f $S/$f $M/$f; done
chmod 0755 $M/service.sh $M/uninstall.sh $M/fand.sh $M/fanctl.sh
chmod 0644 $M/module.prop
rm -f $M/disable $M/remove
sh $M/fanctl.sh start
sleep 3
echo "### status"
sh $M/fanctl.sh status
echo "### installed"
ls -l $M
