#!/system/bin/sh
# Magisk runs this once per boot (late start).
MODDIR=${0%/*}
sleep 10
sh $MODDIR/fanctl.sh start
