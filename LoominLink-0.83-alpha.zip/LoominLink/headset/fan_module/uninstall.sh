#!/system/bin/sh
# Magisk runs this when the module is removed: hand the fan back to Pimax and clean up.
MODDIR=${0%/*}
sh $MODDIR/fanctl.sh stop
for z in /sys/class/thermal/thermal_zone*; do
  [ "$(cat $z/mode 2>/dev/null)" = "disabled" ] && echo enabled > $z/mode 2>/dev/null
done
rm -rf /data/adb/loominlink
