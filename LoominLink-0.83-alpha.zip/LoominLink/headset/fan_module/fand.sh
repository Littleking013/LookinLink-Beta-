#!/system/bin/sh
# LoominLink fan service v2 - runs as root (Magisk starts it at boot).
# The fan driver takes a real duty cycle of 5-99% on its "fan" file; Android's cooling scale (and Pimax's
# own control) stops at 25%. Settings: /data/adb/loominlink/fan.conf   Live status: .../fan_status
# Modes: stock  = Pimax's own control (nothing touched)
#        stream = <stream>% while the LoominLink app runs, stock otherwise (default, 70%)
#        max    = 99% always
#        cool   = curve on the hottest chip: 35% at 60C or less -> 99% at 85C
#        fixed  = <level>% always
# Safety: any setting goes to 99% if a chip reaches 90C or the headset skin reaches 60C.
D=/data/adb/loominlink
CONF=$D/fan.conf
STAT=$D/fan_status
PIDF=$D/fand.pid
LOG=$D/fand.log
APP=com.crystaltools.gazedot
F=/sys/devices/platform/soc/soc:pimax_soc_pwm_fan/fan
mkdir -p $D
[ -f $LOG ] && [ $(wc -c < $LOG) -gt 20000 ] && mv -f $LOG $LOG.old
log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> $LOG; }

if [ -f $PIDF ]; then
  old=$(cat $PIDF 2>/dev/null)
  if [ -n "$old" ] && [ "$old" != "$$" ] && [ -d /proc/$old ] && grep -q fand /proc/$old/cmdline 2>/dev/null; then exit 0; fi
fi
echo $$ > $PIDF
[ -f $CONF ] || printf 'mode=stream\nlevel=50\nstream=70\n' > $CONF
log "start pid $$"

C=""
for c in /sys/class/thermal/cooling_device*; do [ "$(cat $c/type 2>/dev/null)" = "pimax_soc_pwm_fan" ] && C=$c; done
if [ -z "$C" ] || [ ! -e $F ]; then echo "daemon=error" > $STAT; echo "error=fan not found" >> $STAT; log "fan not found"; rm -f $PIDF; exit 1; fi
CR=$(readlink -f $C)
ZONES=""
for z in /sys/class/thermal/thermal_zone*; do
  for l in $z/cdev*; do
    [ -L "$l" ] || continue
    if [ "$(readlink -f $l)" = "$CR" ]; then case " $ZONES " in *" $z "*) ;; *) ZONES="$ZONES $z";; esac; fi
  done
done
SOCZ=""; SKINZ=""
for z in /sys/class/thermal/thermal_zone*; do
  case " $ZONES " in *" $z "*) continue;; esac     # the fan's own zone reads nothing while we hold it
  case "$(cat $z/type 2>/dev/null)" in
    cpu-*|cpuss-*|gpuss-*|gpu-*) SOCZ="$SOCZ $z/temp";;
    skin*|xo-therm*|quiet*) SKINZ="$SKINZ $z/temp";;
  esac
done

deg() { v=$1; case "$v" in ''|*[!0-9]*) v=0;; esac; [ $v -gt 1000 ] && v=$((v / 1000)); echo $v; }
pct() { v=$1; case "$v" in ''|*[!0-9]*) v=$2;; esac; [ $v -lt 5 ] && v=5; [ $v -gt 99 ] && v=99; echo $v; }
duty() { d=$(sed -n 's/.*duty:\([0-9]*\).*/\1/p' $F 2>/dev/null); [ -z "$d" ] && d=0; echo $d; }
CTRL=0
take() { [ $CTRL = 1 ] && return; for z in $ZONES; do echo disabled > $z/mode 2>/dev/null; done; CTRL=1; log "taking the fan"; }
give() { for z in $ZONES; do echo enabled > $z/mode 2>/dev/null; done
         [ $CTRL = 1 ] && { echo 20 > $C/cur_state 2>/dev/null; log "fan back to Pimax"; }; CTRL=0; }
give
trap 'give; rm -f $PIDF; echo "daemon=stopped" > $STAT; log "stopped"; exit 0' TERM INT

while true; do
  mode=stream; lvl=50; spd=70
  while IFS='=' read -r k v; do
    case "$k" in mode) mode=$v;; level) lvl=$v;; stream) spd=$v;; esac
  done < $CONF
  lvl=$(pct "$lvl" 50); spd=$(pct "$spd" 70)

  soc=0;  for f in $SOCZ;  do t=$(deg "$(cat $f 2>/dev/null)"); [ $t -gt $soc ]  && soc=$t;  done
  skin=0; for f in $SKINZ; do t=$(deg "$(cat $f 2>/dev/null)"); [ $t -lt 150 ] && [ $t -gt $skin ] && skin=$t; done
  run=0; pidof $APP >/dev/null 2>&1 && run=1

  want=-1
  case "$mode" in
    max)    want=99 ;;
    stream) [ $run = 1 ] && want=$spd ;;
    fixed)  want=$lvl ;;
    cool)   if [ $soc -le 60 ]; then want=35
            elif [ $soc -ge 85 ]; then want=99
            else want=$((35 + (soc - 60) * 64 / 25)); fi ;;
    *)      want=-1 ;;
  esac
  if [ $want -ge 0 ] && [ $want -lt 99 ]; then
    if [ $soc -ge 90 ] || [ $skin -ge 60 ]; then want=99; fi
  fi

  if [ $want -ge 0 ]; then
    take
    [ "$(duty)" != "$want" ] && echo $want > $F
  elif [ $CTRL = 1 ]; then
    give
  fi

  printf 'daemon=running\nmode=%s\nlevel=%s\nstream=%s\nduty=%s\nsoc=%s\nskin=%s\napp=%s\ncontrol=%s\nt=%s\n' \
    "$mode" "$lvl" "$spd" "$(duty)" "$soc" "$skin" "$run" "$CTRL" "$(date +%s)" > $STAT.tmp && mv $STAT.tmp $STAT
  sleep 2
done
